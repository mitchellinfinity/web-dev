package org.hirstm.webd5201.service;

public interface SecurityService {
    String findLoggedInUsername();

    void autologin(String username, String password);
}
