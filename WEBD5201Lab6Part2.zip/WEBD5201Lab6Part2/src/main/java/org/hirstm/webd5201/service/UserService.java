package org.hirstm.webd5201.service;

import org.hirstm.webd5201.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}